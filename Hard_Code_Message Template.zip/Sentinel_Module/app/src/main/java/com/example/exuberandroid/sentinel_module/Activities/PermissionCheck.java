package com.example.exuberandroid.sentinel_module.Activities;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.test.mock.MockPackageManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;

public class PermissionCheck extends AbsRuntimePermission {
    private static final int REQUEST_PEREMISSION=10;
    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;
    TextView nextBTN;

    //
    private static final int REQUEST_CODE_PERMISSION = 2;
    String mPermission = Manifest.permission.ACCESS_FINE_LOCATION;
    // GPSTracker class
    GPSTracker gps;
    double latitude,longitude;
    String country_name = null;
    //

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissioncheck);
        nextBTN=(TextView) findViewById(R.id.nextBTN);

        sharedPreferences = getSharedPreferences("PREF", 0);
        es=sharedPreferences.edit();
        Log.e("pc out uid",sharedPreferences.getString("userid", ""));
        Log.e("eer","hjj");

        requestAppPermissions(new String[]{Manifest.permission.READ_CONTACTS,
                Manifest.permission.WRITE_CONTACTS,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION},
                R.string.msg, REQUEST_PEREMISSION);



        /////////////////////////////////////////////FOR LAT LONG COUNTRY/////////////////////////////

        //check permission is granted
        //request

        if (ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions((Activity) this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {
                ActivityCompat.requestPermissions((Activity) this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            }
        } else {
            gps = new GPSTracker(PermissionCheck.this);

            // check if GPS enabled
            if(gps.canGetLocation()){

                latitude = gps.getLatitude();
                longitude = gps.getLongitude();

                // \n is for new line
           /* Toast.makeText(getApplicationContext(), "Your Location is - \nLat: "
                    + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();*/
                Log.e("LATITUDE", String.valueOf(latitude));
                Log.e("LONGITUDE", String.valueOf(longitude));
            }else{
                gps.showSettingsAlert();
            }

            ////////////////
            LocationManager lm = (LocationManager)getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
            Geocoder geocoder = new Geocoder(getApplicationContext());
            for(String provider: lm.getAllProviders()) {
                @SuppressWarnings("ResourceType") Location location = lm.getLastKnownLocation(provider);
                if(location!=null) {
                    try {
                        List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                        if(addresses != null && addresses.size() > 0) {
                            country_name = addresses.get(0).getCountryName();
                            break;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            //Toast.makeText(getApplicationContext(), country_name, Toast.LENGTH_LONG).show();
        }

        ////////////////////////////////FOR LAT LONG COUNTRY///////////////////////////////////




        nextBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LocationApiCall();

                /*Intent in=new Intent(PermissionCheck.this,SplashActivity.class);
                startActivity(in);
                finish();*/
            }
        });
    }

    @Override
    public void onPermissionGranted(int requestCode) {

    }

    @Override
    public void onBackPressed() {
        finish();
    }



    public void LocationApiCall() {

        Log.e("pc out uid",sharedPreferences.getString("userid", ""));

        JSONObject jObject = new JSONObject();
        try {

            Log.e("pc uid",sharedPreferences.getString("userid", ""));

            jObject.put("userId",sharedPreferences.getString("userid", ""));
            Constants.USER_ID=sharedPreferences.getString("userid", "");

            jObject.put("gLatitude",latitude);
            Constants.USER_LATITUDE= String.valueOf(latitude);

            jObject.put("gLongitude",longitude);
            Constants.USER_LONGITUDE= String.valueOf(longitude);

            jObject.put("country",country_name);
            Constants.USER_COUNTRY=country_name;

            JSONObject updatedby = new JSONObject();
            updatedby.put("userId", sharedPreferences.getString("userid",""));
            Constants.USER_ID=sharedPreferences.getString("userid", "");
            jObject.put("updatedBy",updatedby);

        } catch (Exception e) {
            e.printStackTrace();
        }

        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jObject.toString());
            Log.d("PermissionCheckObject", String.valueOf(jObject));
        } catch (Exception e) {
            e.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.SHOW_LOCATION);
        Log.e("servicename",Constants.SHOW_LOCATION);

        asyncHttpClient.put(null, Constants.APP_LOCATION_UPDATE_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("OTP_Response", Response);

                Log.v("Status code", statusCode+"");

                if (statusCode==200) {

                    try {
                        JSONObject job = new JSONObject(Response);
                        JSONObject updateby = job.getJSONObject("updatedBy");

                        es.putString(Constants.USER_ID, job.getString("userId"));
                        es.putString("lat", job.getString("gLatitude"));
                        es.putString("longi", job.getString("gLongitude"));
                        es.putString("country", job.getString("country"));
                        es.putString(Constants.USER_ID, updateby.getString("userId"));

                        es.commit();

                        //Log.d("UserId", Constants.USER_ID);
                        Log.d("LAT", Constants.USER_LATITUDE);
                        Log.d("LONGI", Constants.USER_LONGITUDE);
                        Log.d("COUNTRY", Constants.USER_COUNTRY);
                        //Log.d("updatedBYE", Constants.USER_ID);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Intent in = new Intent(PermissionCheck.this, SplashActivity.class);
                    startActivity(in);
                    finish();
                }
                else {
                    Toast.makeText(PermissionCheck.this, "Location not submitted", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Error", String.valueOf(error));
                Log.e("ErrorStatus", String.valueOf(statusCode));

            }
        });

    }


}
