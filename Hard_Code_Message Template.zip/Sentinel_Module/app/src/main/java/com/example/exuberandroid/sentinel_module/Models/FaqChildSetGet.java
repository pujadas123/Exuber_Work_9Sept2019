package com.example.exuberandroid.sentinel_module.Models;

public class FaqChildSetGet {

    String cname;

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }


}