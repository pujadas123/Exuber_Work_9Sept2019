package com.example.exuberandroid.sentinel_module.CustomViews;

import android.app.IntentService;
import android.content.Intent;

public class TimerService extends IntentService {

    public static boolean isRunning = false;

    public TimerService() {
        super("TimerService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        while (isRunning){
            try {
                Thread.sleep(2000);
                sendBroadcast(new Intent("chat"));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
