
package com.example.exuberandroid.sentinel_module.Models.AlarmNewModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AlarmModel {

    @SerializedName("userId")
    @Expose
    private String userId;
    @SerializedName("falseAlarm")
    @Expose
    private String falseAlarm;
    @SerializedName("updatedBy")
    @Expose
    private UpdatedBy updatedBy;

    /**
     * No args constructor for use in serialization
     * 
     */
    public AlarmModel() {
    }

    /**
     * 
     * @param falseAlarm
     * @param userId
     * @param updatedBy
     */
    public AlarmModel(String userId, String falseAlarm, UpdatedBy updatedBy) {
        super();
        this.userId = userId;
        this.falseAlarm = falseAlarm;
        this.updatedBy = updatedBy;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFalseAlarm() {
        return falseAlarm;
    }

    public void setFalseAlarm(String falseAlarm) {
        this.falseAlarm = falseAlarm;
    }

    public UpdatedBy getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(UpdatedBy updatedBy) {
        this.updatedBy = updatedBy;
    }

}
