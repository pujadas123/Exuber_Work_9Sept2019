package com.example.exuberandroid.sentinel_module.Activities;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseExpandableListAdapter;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.exuberandroid.sentinel_module.Adapters.FaqAdapter;
import com.example.exuberandroid.sentinel_module.Adapters.MessageTemplateAdapter;
import com.example.exuberandroid.sentinel_module.Models.FaqChildSetGet;
import com.example.exuberandroid.sentinel_module.Models.FaqHeaderSetGet;
import com.example.exuberandroid.sentinel_module.Models.FaqModel;
import com.example.exuberandroid.sentinel_module.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FAQActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private TextView toolbarTV;


    private RecyclerView recyclerFaq;
    private FaqAdapter faqAdapter;
    ArrayList<FaqModel> itemList = new ArrayList<FaqModel>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq);

        init();




        try {

            JSONArray m_jArry = new JSONArray(FaqObject());

            for (int i = 0; i < m_jArry.length(); i++) {
                JSONObject jo_inside = m_jArry.getJSONObject(i);

                String question = jo_inside.getString("question");
                String answer = jo_inside.getString("answer");

                itemList.add(new FaqModel(question,answer));

                }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        faqAdapter = new FaqAdapter(itemList, FAQActivity.this);
        recyclerFaq.setAdapter(faqAdapter);
        faqAdapter.notifyDataSetChanged();



    }


    private void init() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("FAQ");


        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);



        recyclerFaq = (RecyclerView) findViewById(R.id.recyclerFaq);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerFaq.setLayoutManager(llm);
        recyclerFaq.setHasFixedSize(true);








    }

    public String FaqObject() {
        String json = null;
        try {
            InputStream is = FAQActivity.this.getAssets().open("faq.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }






    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
