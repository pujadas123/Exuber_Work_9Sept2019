
package com.example.exuberandroid.sentinel_module.Models.alarmretromodel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AlarmOutput {

    @SerializedName("userId")
    @Expose
    private String userId;
    @SerializedName("userKey")
    @Expose
    private String userKey;
    @SerializedName("userName")
    @Expose
    private String userName;
    @SerializedName("userEmail")
    @Expose
    private String userEmail;
    @SerializedName("userPassword")
    @Expose
    private Object userPassword;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("otp")
    @Expose
    private String otp;
    @SerializedName("roleId")
    @Expose
    private RoleId roleId;
    @SerializedName("profilePic")
    @Expose
    private String profilePic;
    @SerializedName("deviceId")
    @Expose
    private String deviceId;
    @SerializedName("gLatitude")
    @Expose
    private String gLatitude;
    @SerializedName("gLongitude")
    @Expose
    private String gLongitude;
    @SerializedName("country")
    @Expose
    private String country;
    @SerializedName("falseAlarm")
    @Expose
    private String falseAlarm;
    @SerializedName("bloodGroup")
    @Expose
    private String bloodGroup;
    @SerializedName("doctorName")
    @Expose
    private String doctorName;
    @SerializedName("primaryHospital")
    @Expose
    private String primaryHospital;
    @SerializedName("healthInsuranceCompany")
    @Expose
    private String healthInsuranceCompany;
    @SerializedName("healthInsuranceId")
    @Expose
    private String healthInsuranceId;
    @SerializedName("allergies")
    @Expose
    private String allergies;
    @SerializedName("diabetes")
    @Expose
    private String diabetes;
    @SerializedName("preferenceLanguage")
    @Expose
    private Object preferenceLanguage;
    @SerializedName("devicePlatform")
    @Expose
    private String devicePlatform;
    @SerializedName("field1")
    @Expose
    private Object field1;
    @SerializedName("field2")
    @Expose
    private Object field2;
    @SerializedName("field3")
    @Expose
    private Object field3;
    @SerializedName("field4")
    @Expose
    private Object field4;
    @SerializedName("socialType")
    @Expose
    private Object socialType;
    @SerializedName("socialId")
    @Expose
    private Object socialId;
    @SerializedName("socialImage")
    @Expose
    private Object socialImage;
    @SerializedName("dataStatus")
    @Expose
    private String dataStatus;
    @SerializedName("createdBy")
    @Expose
    private CreatedBy createdBy;
    @SerializedName("createdOn")
    @Expose
    private Double createdOn;
    @SerializedName("updatedBy")
    @Expose
    private UpdatedBy updatedBy;
    @SerializedName("updatedOn")
    @Expose
    private Double updatedOn;
    @SerializedName("verification")
    @Expose
    private String verification;
    @SerializedName("accessId")
    @Expose
    private Object accessId;
    @SerializedName("address")
    @Expose
    private String address;
    @SerializedName("locale")
    @Expose
    private String locale;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserKey() {
        return userKey;
    }

    public void setUserKey(String userKey) {
        this.userKey = userKey;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Object getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(Object userPassword) {
        this.userPassword = userPassword;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public RoleId getRoleId() {
        return roleId;
    }

    public void setRoleId(RoleId roleId) {
        this.roleId = roleId;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getGLatitude() {
        return gLatitude;
    }

    public void setGLatitude(String gLatitude) {
        this.gLatitude = gLatitude;
    }

    public String getGLongitude() {
        return gLongitude;
    }

    public void setGLongitude(String gLongitude) {
        this.gLongitude = gLongitude;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getFalseAlarm() {
        return falseAlarm;
    }

    public void setFalseAlarm(String falseAlarm) {
        this.falseAlarm = falseAlarm;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getPrimaryHospital() {
        return primaryHospital;
    }

    public void setPrimaryHospital(String primaryHospital) {
        this.primaryHospital = primaryHospital;
    }

    public String getHealthInsuranceCompany() {
        return healthInsuranceCompany;
    }

    public void setHealthInsuranceCompany(String healthInsuranceCompany) {
        this.healthInsuranceCompany = healthInsuranceCompany;
    }

    public String getHealthInsuranceId() {
        return healthInsuranceId;
    }

    public void setHealthInsuranceId(String healthInsuranceId) {
        this.healthInsuranceId = healthInsuranceId;
    }

    public String getAllergies() {
        return allergies;
    }

    public void setAllergies(String allergies) {
        this.allergies = allergies;
    }

    public String getDiabetes() {
        return diabetes;
    }

    public void setDiabetes(String diabetes) {
        this.diabetes = diabetes;
    }

    public Object getPreferenceLanguage() {
        return preferenceLanguage;
    }

    public void setPreferenceLanguage(Object preferenceLanguage) {
        this.preferenceLanguage = preferenceLanguage;
    }

    public String getDevicePlatform() {
        return devicePlatform;
    }

    public void setDevicePlatform(String devicePlatform) {
        this.devicePlatform = devicePlatform;
    }

    public Object getField1() {
        return field1;
    }

    public void setField1(Object field1) {
        this.field1 = field1;
    }

    public Object getField2() {
        return field2;
    }

    public void setField2(Object field2) {
        this.field2 = field2;
    }

    public Object getField3() {
        return field3;
    }

    public void setField3(Object field3) {
        this.field3 = field3;
    }

    public Object getField4() {
        return field4;
    }

    public void setField4(Object field4) {
        this.field4 = field4;
    }

    public Object getSocialType() {
        return socialType;
    }

    public void setSocialType(Object socialType) {
        this.socialType = socialType;
    }

    public Object getSocialId() {
        return socialId;
    }

    public void setSocialId(Object socialId) {
        this.socialId = socialId;
    }

    public Object getSocialImage() {
        return socialImage;
    }

    public void setSocialImage(Object socialImage) {
        this.socialImage = socialImage;
    }

    public String getDataStatus() {
        return dataStatus;
    }

    public void setDataStatus(String dataStatus) {
        this.dataStatus = dataStatus;
    }

    public CreatedBy getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(CreatedBy createdBy) {
        this.createdBy = createdBy;
    }

    public Double getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Double createdOn) {
        this.createdOn = createdOn;
    }

    public UpdatedBy getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(UpdatedBy updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Double getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Double updatedOn) {
        this.updatedOn = updatedOn;
    }

    public String getVerification() {
        return verification;
    }

    public void setVerification(String verification) {
        this.verification = verification;
    }

    public Object getAccessId() {
        return accessId;
    }

    public void setAccessId(Object accessId) {
        this.accessId = accessId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

}
