package com.example.exuberandroid.sentinel_module.Adapters;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.exuberandroid.sentinel_module.R;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class DrawerAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<String> drawerItemsArrayList;
    private ArrayList<Integer> imagesArrayList;
    private LayoutInflater inflater;

    public DrawerAdapter(Context context) {
        this.context = context;

        inflater = LayoutInflater.from(context);
        drawerItemsArrayList = new ArrayList<>();
        drawerItemsArrayList.add("My Profile");
        drawerItemsArrayList.add("About Us");
        drawerItemsArrayList.add("Emergency Contacts");
        drawerItemsArrayList.add("Message Templates");
        drawerItemsArrayList.add("Privacy Policy");
        /*drawerItemsArrayList.add("Help");
        drawerItemsArrayList.add("Logout");*/
        drawerItemsArrayList.add("Invite Friends");


        imagesArrayList = new ArrayList<>();
        imagesArrayList.add(R.drawable.icon_my_profile);
        imagesArrayList.add(R.drawable.icon_about_us);
        imagesArrayList.add(R.drawable.emergency_contact);
        imagesArrayList.add(R.drawable.email);
        imagesArrayList.add(R.drawable.policy);
        /*imagesArrayList.add(R.drawable.help);
        imagesArrayList.add(R.drawable.icon_logout)*/;
        imagesArrayList.add(R.drawable.share);
    }

    @Override
    public int getCount() {
        return drawerItemsArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup viewGroup) {
        final MyViewHolder myViewHolder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.single_row_drawer_items, viewGroup, false);
            myViewHolder = new MyViewHolder(convertView);
            convertView.setTag(myViewHolder);
        } else {
            myViewHolder = (MyViewHolder) convertView.getTag();
        }

        myViewHolder.ivItemImage.setImageResource(imagesArrayList.get(position));

        myViewHolder.tvItemName.setText(drawerItemsArrayList.get(position));


        return convertView;
    }

    private class MyViewHolder {

        TextView tvItemName;
        ImageView ivItemImage;
        LinearLayout parentLayout;

        public MyViewHolder(View view) {
            tvItemName = (TextView) view.findViewById(R.id.tv_drawer_item_name);
            ivItemImage = (ImageView) view.findViewById(R.id.iv_drawer_item_icon);
            parentLayout = (LinearLayout) view.findViewById(R.id.parent_layout);
        }

    }

}
