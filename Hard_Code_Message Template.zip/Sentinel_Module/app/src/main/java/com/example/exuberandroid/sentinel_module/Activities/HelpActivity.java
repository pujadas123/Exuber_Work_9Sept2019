package com.example.exuberandroid.sentinel_module.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.example.exuberandroid.sentinel_module.Models.HelpChildSetGet;
import com.example.exuberandroid.sentinel_module.Models.HelpHeaderSet;
import com.example.exuberandroid.sentinel_module.R;

import java.util.ArrayList;

public class HelpActivity extends AppCompatActivity{
    private Toolbar mToolbar;
    private TextView toolbarTV;

    ExpandableListView expand_a;
    ArrayList<HelpHeaderSet> harrlst = new ArrayList<HelpHeaderSet>();
    ArrayList<HelpChildSetGet> carrlst;
    HelpChildSetGet cobj;
    HelpHeaderSet hobj;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        init();
    }


    private void init() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("Help");


        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);
        loaddata();
        expand_a=(ExpandableListView)findViewById(R.id.expand);
        expand_a.setAdapter(new MyAdapter());
        expand_a.expandGroup(0);


        ////


        expand_a.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {

                switch (groupPosition){
                    case 0:
                        Intent Open = new Intent(v.getContext(), TutorialActivity.class);
                        startActivity(Open);
                        break;
                    case 1:
                        Intent Open1 = new Intent(v.getContext(), WelcomeSlidesActivity.class);
                        startActivity(Open1);
                        break;
                    case 2:
                        Intent Open2 = new Intent(v.getContext(), FAQActivity.class);
                        startActivity(Open2);
                        break;
                    case 3:
                        Intent Open3 = new Intent(v.getContext(), ContactUsActivity.class);
                        startActivity(Open3);
                        break;
                }
                return false;
            }
        });

        ////

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    public class MyAdapter extends BaseExpandableListAdapter {

        @Override
        public Object getChild(int arg0, int arg1) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public long getChildId(int arg0, int arg1) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View crow, ViewGroup parent) {
            // TODO Auto-generated method stub
            crow = getLayoutInflater().inflate(R.layout.activity_my_account_child_set_get, parent, false);
            TextView ctv = (TextView) crow.findViewById(R.id.ct);
            ctv.setText(harrlst.get(groupPosition).getcArrayList().get(childPosition).getCname());
            return crow;
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            // TODO Auto-generated method stub
            return harrlst.get(groupPosition).getcArrayList().size();
        }

        @Override
        public Object getGroup(int arg0) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public int getGroupCount() {
            // TODO Auto-generated method stub
            return harrlst.size();
        }

        @Override
        public long getGroupId(int arg0) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View hrow, ViewGroup parent) {
            // TODO Auto-generated method stub

            hrow = getLayoutInflater().inflate(R.layout.activity_my_account_header_set, parent, false);
            TextView htv = (TextView) hrow.findViewById(R.id.ht);
            htv.setText(harrlst.get(groupPosition).getHname());
            //ImageView ivGroupIndicator_a=(ImageView)hrow.findViewById(R.id.ivGroupIndicator);

            return hrow;
        }

        @Override
        public boolean hasStableIds() {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public boolean isChildSelectable(int arg0, int arg1) {
            // TODO Auto-generated method stub
            return true;
        }
    }


    public void loaddata() {
        carrlst = new ArrayList<HelpChildSetGet>();

        hobj= new HelpHeaderSet();
        hobj.setHname("Tutorial");
        hobj.setcArrayList(carrlst);
        harrlst.add(hobj);

        hobj= new HelpHeaderSet();
        hobj.setHname("Welcome Slides");
        hobj.setcArrayList(carrlst);
        harrlst.add(hobj);

        hobj= new HelpHeaderSet();
        hobj.setHname("FAQ");
        hobj.setcArrayList(carrlst);
        harrlst.add(hobj);

        hobj= new HelpHeaderSet();
        hobj.setHname("Contact Us");
        hobj.setcArrayList(carrlst);
        harrlst.add(hobj);

    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
