package com.example.exuberandroid.sentinel_module.Utils;

public class Constants {

    //Sharedpreference values
    public static final String SHARED_PREFERENCES = "shared_preferences_2";

    public static final String REGISTERED_MOBILE = "registered_mobile";

    public static final String IS_LOGGED_IN = "logged_in";


    //JSON Tag from response from server
    public static final String TAG_RESPONSE= "ErrorMessage";


    public static final String CHAT_IMAGES_DIRECTORY = "/CorporateStop/chat_images/";

    public static String USER_NAME = "user_name";
    public static String USER_EMAIL = "user_email";
    public static String USER_PHNO = "user_phno";
    public static String USER_OTP = "user_otp";
    public static String USER_ID = "user_id";
    public static String USER_KEY = "user_key";
    public static String ACCESS_TOKEN_ID = "access_token_id";
    public static String ROLE_ID = "role_id";
    public static String FALSE_ALARM = "false_alarm";
    public static String USER_LATITUDE = "user_latitude";
    public static String USER_LONGITUDE = "user_longitude";
    public static String USER_COUNTRY = "user_country";
    public static String USER_ADDRESS = "user_address";
    public static String USER_BLOOD_GRP = "user_blood_grp";
    public static String USER_DOCTOR_NAME = "user_doctor_name";
    public static String USER_PRIMARY_HOSPITAL = "user_primary_hospital";
    public static String USER_HEALTH_INSURANCE_COMPANY = "user_health_insurance_company";
    public static String USER_HEALTH_INSURANCEID = "user_health_insuranceid";
    public static String USER_ALLERGIES = "user_allergies";
    public static String USER_DIABETES = "user_diabetes";
    public static String USER_MESSAGE_TEMPLATE_ID = "user_message_template_id";
    public static final String STUDENT_PIC_URL = "student_pic_url";




    //Header Services Name....
    public static String ADD_CONTACT_SERVICE = "RegisterEmergencyContact";

    public static String SET_FALSE_ALARM = "UpdateFalseAlarmCode";

    public static String SHOW_MESSAGE_TEMPLATE = "GetAllTypeMessages";

    public static String SHOW_CONTACT_BYUSER = "GetAllEmergencyContactsByUser";

    public static String SHOW_LOCATION = "UpdateLocation";

    public static String SHOW_USER_PROFILE = "UpdateUserProfile";


    public static String SHOW_EMERGENCY_CONTACT_MSG_TEMPLATE = "GetAllEmergencyContactsMsgTempByUser";


    ////////////////////////

    public static String USER_UPDATE_MESSAGE_TEMPLATE = "UpdateEmergencyContactMessageTemplate";




    //////////////4 buttons.....................

    public static String USER_REGISTER_GENERAL_MESSAGE_BY_USERID = "RegisterGeneralMessageByUserId";

    public static String USER_REGISTER_LOCATION_MESSAGE_BY_USERID = "RegisterLocationMessageByUserId";

    public static String USER_REGISTER_MEDICAL_MESSAGE_BY_USERID = "RegisterMedicalMessageByUserId";

    public static String USER_REGISTER_PROTECTME_MESSAGE_BY_USERID = "RegisterProtectMessageByUserId";

    public static String USER_REGISTER_COMMUNITY_MESSAGE_BY_USERID = "RegisterCommunityMessageByUserId";

    //public static String USER_REGISTER_ACTION_MESSAGE_BY_USERID = "RegisterActionMessageByUserId";




    ///Services..............

    public static final String DOMAIN = "http://sentinel.ap-south-1.elasticbeanstalk.com";

    public static final String APP_LOGIN_API = DOMAIN + "/Login/";     //GET Request

    //public static final String APP_SIGNUP_API = DOMAIN + "/Admin/RegisterUserProfile/";    //POST Request

    //public static final String APP_OTP_API = DOMAIN + "/Admin/UpdateUserProfileVerification/";    //PUT Request

    //
    public static final String APP_SIGNUP_API = DOMAIN + "/Admin/RegisterOTP/";    //POST Request

    public static final String REGISTER_USER_API = DOMAIN + "/Admin/RegisterUserProfile/";    //POST Request
    //

    public static final String APP_ADD_EMERGENCY_CONTACT_API = DOMAIN + "/Admin/RegisterEmergencyContact/";    //POST Request

    public static final String APP_SHOW_EMERGENCY_CONTACT_API = DOMAIN + "/Admin/GetAllEmergencyContactsByUser/";    //GET Request

    public static final String APP_SET_FALSE_AlARM_API = DOMAIN + "/Admin/UpdateFalseAlarmCode/";    //POST Request

    public static final String APP_MESSAGE_TEMPLATE_API = DOMAIN + "/Admin/GetAllTypeMessages/";    //GET Request

    public static final String APP_LOCATION_UPDATE_API = DOMAIN + "/Admin/UpdateLocation/";    //PUT Request

    public static final String APP_USER_PROFILE_UPDATE_API = DOMAIN + "/Admin/UpdateUserProfile/";    //PUT Request

    //////////////////////

    public static final String APP_UPDATE_MESSAGE_TEMPLATE_API = DOMAIN + "/Admin/UpdateEmergencyContactMessageTemplate/";    //PUT Request






    ////////////////// 4 buttons.....................

    public static final String APP_REGISTER_GENERAL_MESSAGE_BY_USERID_API = DOMAIN + "/Admin/RegisterGeneralMessageByUserId/";    //POST Request

    public static final String APP_REGISTER_LOCATION_MESSAGE_BY_USERID_API = DOMAIN + "/Admin/RegisterLocationMessageByUserId/";    //POST Request

    public static final String APP_REGISTER_MEDICAL_MESSAGE_BY_USERID_API = DOMAIN + "/Admin/RegisterMedicalMessageByUserId/";    //POST Request

    public static final String APP_REGISTER_PROTECTME_MESSAGE_BY_USERID_API = DOMAIN + "/Admin/RegisterProtectMessageByUserId/";    //POST Request

    public static final String APP_REGISTER_COMMUNITY_MESSAGE_BY_USERID_API = DOMAIN + "/Admin/RegisterCommunityMessageByUserId/";    //POST Request

    public static final String APP_GET_ALL_EMERGENCY_CONTACT_MESSAGETEMPLATE_API = DOMAIN + "/Admin/GetAllEmergencyContactsMsgTempByUser/";    //POST Request

    public static final String APP_SUBMIT_PROFILE_IMAGE_API = DOMAIN + "/Admin/UploadProfilepic/";    //POST Request





}
