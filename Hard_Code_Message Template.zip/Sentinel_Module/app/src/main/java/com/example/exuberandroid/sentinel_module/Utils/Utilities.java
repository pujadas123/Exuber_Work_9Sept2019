package com.example.exuberandroid.sentinel_module.Utils;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utilities {
    static ProgressDialog pDialog = null;
    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy");


    public static boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }

    public static void showToast(Context context, String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    public static void showNoConnectionToast(Context context) {
        Toast.makeText(context, "No Internet connection", Toast.LENGTH_SHORT).show();
    }

    public static void handleVolleyError(Context context, VolleyError volleyError) {
        volleyError.printStackTrace();
//        if (volleyError.networkResponse == null) {
//            if (volleyError.getClass().equals(NoConnectionError.class)) {
//                Utilities.showNoConnectionToast(context);
//            }
//        }
//        if (volleyError.networkResponse == null) {
//            if (volleyError.getClass().equals(TimeoutError.class)) {
//                Utilities.showTimeOutToast(context);
//            }
//        } else {
//            Utilities.showSomethingWrongToast(context);
//        }

        if (volleyError instanceof TimeoutError) {
            Utilities.showToast(context, "Time Out Error");

        } else if (volleyError instanceof NoConnectionError) {
            Utilities.showToast(context, "No Connection Error");

        } else if (volleyError instanceof AuthFailureError) {
            //TODO
            Toast.makeText(context, "Authentication Failure", Toast.LENGTH_LONG).show();
        } else if (volleyError instanceof ServerError) {
            //TODO
            Toast.makeText(context, "Server Error", Toast.LENGTH_LONG).show();
        } else if (volleyError instanceof NetworkError) {
            //TODO
            Toast.makeText(context, "Network Error", Toast.LENGTH_LONG).show();
        } else if (volleyError instanceof ParseError) {
            //TODO
            Toast.makeText(context, "Parse Error", Toast.LENGTH_LONG).show();
        }
    }


    public static File bitmapToFile(Context context, Bitmap bitmap, boolean compress) {

        String filename = "image_"+System.currentTimeMillis()+".png";
        File f = new File(context.getCacheDir(), filename);
        try {
            f.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        if (compress) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
        } else {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
        }
        byte[] bitmapdata = bos.toByteArray();

        //write the bytes in file
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(f);
            fos.write(bitmapdata);
            fos.flush();
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return f;

    }

    public static void showErrorLog(String tag, String msg) {
        Log.e(tag, msg);
    }
}
