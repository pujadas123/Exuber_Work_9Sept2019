package com.example.exuberandroid.sentinel_module.Adapters;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.exuberandroid.sentinel_module.Activities.FAQActivity;
import com.example.exuberandroid.sentinel_module.Models.FaqModel;
import com.example.exuberandroid.sentinel_module.Models.MessageTemplateMainModel;
import com.example.exuberandroid.sentinel_module.R;

import java.util.ArrayList;
import java.util.List;

public class FaqAdapter extends RecyclerView.Adapter<FaqAdapter.MyViewHolder> {
    private ArrayList<FaqModel> itemList = new ArrayList<>();
    private Context context;

    public FaqAdapter(ArrayList<FaqModel> itemList, Context context){
        this.itemList=itemList;
        this.context=context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_faq,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.text_temp_head.setText(itemList.get(position).getQuestion());
        holder.txtContent.setText(itemList.get(position).getAnswer());

        holder.cv_basic_info_details.setVisibility(View.GONE);

    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView text_temp_head, txtContent;
        private CardView cardview,cv_basic_info_details;
        private ImageView basic_info_expand_icon;
        private boolean basicInfoStaus = true;
        public MyViewHolder(View itemView) {
            super(itemView);
            text_temp_head=(TextView)itemView.findViewById(R.id.text_temp_head);
            txtContent=(TextView)itemView.findViewById(R.id.txtContent);

            cardview=(CardView)itemView.findViewById(R.id.cardview);
            cv_basic_info_details=(CardView)itemView.findViewById(R.id.cv_basic_info_details);
            basic_info_expand_icon=(ImageView)itemView.findViewById(R.id.basic_info_expand_icon);


            cardview.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.cardview:

                    if (cv_basic_info_details.getVisibility() == View.GONE)
                    {
                        cv_basic_info_details.setVisibility(View.VISIBLE);
                        basic_info_expand_icon.setImageResource(R.drawable.help_arrow2);
                    }
                    else
                    {
                        cv_basic_info_details.setVisibility(View.GONE);
                        basic_info_expand_icon.setImageResource(R.drawable.help_arrow);
                    }

                    break;

            }
        }
    }
}
