
package com.example.exuberandroid.sentinel_module.Models.alarmretromodel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UpdatedBy {

    @SerializedName("userId")
    @Expose
    private Object userId;
    @SerializedName("userKey")
    @Expose
    private Object userKey;
    @SerializedName("userName")
    @Expose
    private String userName;
    @SerializedName("userEmail")
    @Expose
    private Object userEmail;
    @SerializedName("userPassword")
    @Expose
    private Object userPassword;
    @SerializedName("phoneNumber")
    @Expose
    private Object phoneNumber;
    @SerializedName("otp")
    @Expose
    private Object otp;
    @SerializedName("roleId")
    @Expose
    private Object roleId;
    @SerializedName("profilePic")
    @Expose
    private Object profilePic;
    @SerializedName("deviceId")
    @Expose
    private Object deviceId;
    @SerializedName("gLatitude")
    @Expose
    private Object gLatitude;
    @SerializedName("gLongitude")
    @Expose
    private Object gLongitude;
    @SerializedName("country")
    @Expose
    private Object country;
    @SerializedName("falseAlarm")
    @Expose
    private Object falseAlarm;
    @SerializedName("bloodGroup")
    @Expose
    private Object bloodGroup;
    @SerializedName("doctorName")
    @Expose
    private Object doctorName;
    @SerializedName("primaryHospital")
    @Expose
    private Object primaryHospital;
    @SerializedName("healthInsuranceCompany")
    @Expose
    private Object healthInsuranceCompany;
    @SerializedName("healthInsuranceId")
    @Expose
    private Object healthInsuranceId;
    @SerializedName("allergies")
    @Expose
    private Object allergies;
    @SerializedName("diabetes")
    @Expose
    private Object diabetes;
    @SerializedName("preferenceLanguage")
    @Expose
    private Object preferenceLanguage;
    @SerializedName("devicePlatform")
    @Expose
    private Object devicePlatform;
    @SerializedName("field1")
    @Expose
    private Object field1;
    @SerializedName("field2")
    @Expose
    private Object field2;
    @SerializedName("field3")
    @Expose
    private Object field3;
    @SerializedName("field4")
    @Expose
    private Object field4;
    @SerializedName("socialType")
    @Expose
    private Object socialType;
    @SerializedName("socialId")
    @Expose
    private Object socialId;
    @SerializedName("socialImage")
    @Expose
    private Object socialImage;
    @SerializedName("dataStatus")
    @Expose
    private Object dataStatus;
    @SerializedName("createdBy")
    @Expose
    private Object createdBy;
    @SerializedName("createdOn")
    @Expose
    private Object createdOn;
    @SerializedName("updatedBy")
    @Expose
    private Object updatedBy;
    @SerializedName("updatedOn")
    @Expose
    private Object updatedOn;
    @SerializedName("verification")
    @Expose
    private Object verification;
    @SerializedName("accessId")
    @Expose
    private Object accessId;
    @SerializedName("address")
    @Expose
    private Object address;
    @SerializedName("locale")
    @Expose
    private Object locale;

    public Object getUserId() {
        return userId;
    }

    public void setUserId(Object userId) {
        this.userId = userId;
    }

    public Object getUserKey() {
        return userKey;
    }

    public void setUserKey(Object userKey) {
        this.userKey = userKey;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Object getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(Object userEmail) {
        this.userEmail = userEmail;
    }

    public Object getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(Object userPassword) {
        this.userPassword = userPassword;
    }

    public Object getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Object phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Object getOtp() {
        return otp;
    }

    public void setOtp(Object otp) {
        this.otp = otp;
    }

    public Object getRoleId() {
        return roleId;
    }

    public void setRoleId(Object roleId) {
        this.roleId = roleId;
    }

    public Object getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(Object profilePic) {
        this.profilePic = profilePic;
    }

    public Object getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Object deviceId) {
        this.deviceId = deviceId;
    }

    public Object getGLatitude() {
        return gLatitude;
    }

    public void setGLatitude(Object gLatitude) {
        this.gLatitude = gLatitude;
    }

    public Object getGLongitude() {
        return gLongitude;
    }

    public void setGLongitude(Object gLongitude) {
        this.gLongitude = gLongitude;
    }

    public Object getCountry() {
        return country;
    }

    public void setCountry(Object country) {
        this.country = country;
    }

    public Object getFalseAlarm() {
        return falseAlarm;
    }

    public void setFalseAlarm(Object falseAlarm) {
        this.falseAlarm = falseAlarm;
    }

    public Object getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(Object bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public Object getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(Object doctorName) {
        this.doctorName = doctorName;
    }

    public Object getPrimaryHospital() {
        return primaryHospital;
    }

    public void setPrimaryHospital(Object primaryHospital) {
        this.primaryHospital = primaryHospital;
    }

    public Object getHealthInsuranceCompany() {
        return healthInsuranceCompany;
    }

    public void setHealthInsuranceCompany(Object healthInsuranceCompany) {
        this.healthInsuranceCompany = healthInsuranceCompany;
    }

    public Object getHealthInsuranceId() {
        return healthInsuranceId;
    }

    public void setHealthInsuranceId(Object healthInsuranceId) {
        this.healthInsuranceId = healthInsuranceId;
    }

    public Object getAllergies() {
        return allergies;
    }

    public void setAllergies(Object allergies) {
        this.allergies = allergies;
    }

    public Object getDiabetes() {
        return diabetes;
    }

    public void setDiabetes(Object diabetes) {
        this.diabetes = diabetes;
    }

    public Object getPreferenceLanguage() {
        return preferenceLanguage;
    }

    public void setPreferenceLanguage(Object preferenceLanguage) {
        this.preferenceLanguage = preferenceLanguage;
    }

    public Object getDevicePlatform() {
        return devicePlatform;
    }

    public void setDevicePlatform(Object devicePlatform) {
        this.devicePlatform = devicePlatform;
    }

    public Object getField1() {
        return field1;
    }

    public void setField1(Object field1) {
        this.field1 = field1;
    }

    public Object getField2() {
        return field2;
    }

    public void setField2(Object field2) {
        this.field2 = field2;
    }

    public Object getField3() {
        return field3;
    }

    public void setField3(Object field3) {
        this.field3 = field3;
    }

    public Object getField4() {
        return field4;
    }

    public void setField4(Object field4) {
        this.field4 = field4;
    }

    public Object getSocialType() {
        return socialType;
    }

    public void setSocialType(Object socialType) {
        this.socialType = socialType;
    }

    public Object getSocialId() {
        return socialId;
    }

    public void setSocialId(Object socialId) {
        this.socialId = socialId;
    }

    public Object getSocialImage() {
        return socialImage;
    }

    public void setSocialImage(Object socialImage) {
        this.socialImage = socialImage;
    }

    public Object getDataStatus() {
        return dataStatus;
    }

    public void setDataStatus(Object dataStatus) {
        this.dataStatus = dataStatus;
    }

    public Object getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Object createdBy) {
        this.createdBy = createdBy;
    }

    public Object getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Object createdOn) {
        this.createdOn = createdOn;
    }

    public Object getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Object updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Object getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Object updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Object getVerification() {
        return verification;
    }

    public void setVerification(Object verification) {
        this.verification = verification;
    }

    public Object getAccessId() {
        return accessId;
    }

    public void setAccessId(Object accessId) {
        this.accessId = accessId;
    }

    public Object getAddress() {
        return address;
    }

    public void setAddress(Object address) {
        this.address = address;
    }

    public Object getLocale() {
        return locale;
    }

    public void setLocale(Object locale) {
        this.locale = locale;
    }

}
