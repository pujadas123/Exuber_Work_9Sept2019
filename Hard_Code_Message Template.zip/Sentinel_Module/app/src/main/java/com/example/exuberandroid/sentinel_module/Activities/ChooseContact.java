package com.example.exuberandroid.sentinel_module.Activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.SpannableStringBuilder;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.Models.SelectedContact;
import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.onegravity.contactpicker.ContactElement;
import com.onegravity.contactpicker.contact.Contact;
import com.onegravity.contactpicker.contact.ContactDescription;
import com.onegravity.contactpicker.contact.ContactSortOrder;
import com.onegravity.contactpicker.core.ContactPickerActivity;
import com.onegravity.contactpicker.group.Group;
import com.onegravity.contactpicker.picture.ContactPictureType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.HttpHeaders;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;
import cz.msebera.android.httpclient.client.methods.RequestBuilder;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.impl.client.HttpClients;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

public class ChooseContact extends AppCompatActivity {

    private Toolbar mToolbar;
    private TextView toolbarTV;

    private static final String EXTRA_DARK_THEME = "EXTRA_DARK_THEME";
    private static final String EXTRA_GROUPS = "EXTRA_GROUPS";
    private static final String EXTRA_CONTACTS = "EXTRA_CONTACTS";

    private static final int REQUEST_CONTACT =10;

    private boolean mDarkTheme;
    private List<Contact> mContacts;
    private List<Group> mGroups;
    TextView contactsView;
    TextView nextBTN;
    SpannableStringBuilder result;

    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;

    String MessageTemplateId="7";

    ArrayList<SelectedContact>Contact=new ArrayList<SelectedContact>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sharedPreferences = getSharedPreferences("PREF", 0);
        es=sharedPreferences.edit();

        // read parameters either from the Intent or from the Bundle
        if (savedInstanceState != null) {
            mDarkTheme = savedInstanceState.getBoolean(EXTRA_DARK_THEME);
            mGroups = (List<Group>) savedInstanceState.getSerializable(EXTRA_GROUPS);
            mContacts = (List<Contact>) savedInstanceState.getSerializable(EXTRA_CONTACTS);
        } else {
            Intent intent = getIntent();
            mDarkTheme = intent.getBooleanExtra(EXTRA_DARK_THEME, false);
            mGroups = (List<Group>) intent.getSerializableExtra(EXTRA_GROUPS);
            mContacts = (List<Contact>) intent.getSerializableExtra(EXTRA_CONTACTS);
        }

        setTheme(mDarkTheme ? R.style.Theme_Dark : R.style.Theme_Light);

        setContentView(R.layout.activity_choose_contact);
        ImageButton button = (ImageButton) findViewById(R.id.pick_contact);
        nextBTN = (TextView) findViewById(R.id.nextBTN);
        contactsView = (TextView) findViewById(R.id.contacts);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(mToolbar);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        //toolbarTV.setText("Choose Contact");



        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    /*try {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("userId", Constants.USER_ID);
                        jsonObject.put("messageTemplateId",MessageTemplateId);
                        jsonObject.put("phoneNumber", Constants.USER_PHNO);
                        jsonObject.put("contactName", Constants.USER_NAME);
                        jsonObject.put("userId", Constants.USER_ID);

                        AddEmergencyContact(jsonObject);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }*/



                    Intent intent = new Intent(ChooseContact.this, ContactPickerActivity.class)
                            .putExtra(ContactPickerActivity.EXTRA_THEME, mDarkTheme ? R.style.Theme_Dark : R.style.Theme_Light)
                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_BADGE_TYPE, ContactPictureType.ROUND.name())
                            .putExtra(ContactPickerActivity.EXTRA_SHOW_CHECK_ALL, true)
                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_DESCRIPTION, ContactDescription.ADDRESS.name())
                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_DESCRIPTION_TYPE, ContactsContract.CommonDataKinds.Email.TYPE_WORK)
                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_SORT_ORDER, ContactSortOrder.AUTOMATIC.name());
                    startActivityForResult(intent, REQUEST_CONTACT);
                }
            });
        } else {
            finish();
        }


        nextBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(contactsView !=null)
                {

                    Log.d("Line No", String.valueOf(contactsView.getLineCount()));
                    Log.d("Contact List",contactsView.getText().toString());
                    if (contactsView.getLineCount() > 1){

                        AddEmergencyContact();
                    }
                    else {
                        Toast.makeText(ChooseContact.this, "Please pick at least 1 Sentinel", Toast.LENGTH_SHORT).show();
                    }


                }
                else {

                }
            }
        });
    }



    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putBoolean(EXTRA_DARK_THEME, mDarkTheme);
        if (mGroups != null) {
            outState.putSerializable(EXTRA_GROUPS, (Serializable) mGroups);
        }
        if (mContacts != null) {
            outState.putSerializable(EXTRA_CONTACTS, (Serializable) mContacts);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CONTACT && resultCode == Activity.RESULT_OK && data != null &&
                (data.hasExtra(ContactPickerActivity.RESULT_GROUP_DATA) ||
                        data.hasExtra(ContactPickerActivity.RESULT_CONTACT_DATA))) {

            // we got a result from the contact picker --> show the picked contacts
            mGroups = (List<Group>) data.getSerializableExtra(ContactPickerActivity.RESULT_GROUP_DATA);
            mContacts = (List<Contact>) data.getSerializableExtra(ContactPickerActivity.RESULT_CONTACT_DATA);
            populateContactList(mGroups, mContacts);
        }
    }


    private void populateContactList(List<Group> groups, List<Contact> contacts) {
        // we got a result from the contact picker --> show the picked contacts

        result = new SpannableStringBuilder();

        try {
            if (groups != null && ! groups.isEmpty()) {
                //result.append("GROUPS\n");
                for (Group group : groups) {
                    populateContact(result, group, "");
                    Contact.clear();
                    for (Contact contact : group.getContacts()) {
                        populateContact(result, contact, "    ");


                        SelectedContact selectedContact=new SelectedContact();
                        selectedContact.setContactName(contact.getDisplayName());
                        selectedContact.setContactNumber(contact.getPhone(0));
                        Contact.add(selectedContact);
                        Log.e("Contact", contact.getDisplayName());
                        Log.e("ContactNumber",  contact.getPhone(0));
                    }
                }
            }
            if (contacts != null && ! contacts.isEmpty()) {
                //result.append("CONTACTS\n");
                Contact.clear();
                for (Contact contact : contacts) {
                    populateContact(result, contact, "");

                    contact.getDisplayName();

                    SelectedContact selectedContact=new SelectedContact();
                    selectedContact.setContactName(contact.getDisplayName());
                    selectedContact.setContactNumber(contact.getPhone(0));
                    Contact.add(selectedContact);
                    Log.e("Contact", contact.getDisplayName());
                    Log.e("ContactNumber",  contact.getPhone(0));

                }
            }
        }
        catch (Exception e) {
            result.append(e.getMessage());
        }

        contactsView.setText(result);
    }

    private void populateContact(SpannableStringBuilder result, ContactElement element, String prefix) {
        //int start = result.length();

        String displayName = element.getDisplayName();

        result.append(prefix);
        result.append(displayName + "\n");
        //result.setSpan(new BulletSpan(15), start, result.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
    }



    public void AddEmergencyContact() {
        //create json array
        JSONArray jArray=new JSONArray();

        for (int i=0; i<Contact.size(); i++) {
            try {

                JSONObject jsonObject = new JSONObject();

                JSONObject uderidobj = new JSONObject();
                uderidobj.put("userId", sharedPreferences.getString("userid", ""));
                Constants.USER_ID=sharedPreferences.getString("userid", "");

                jsonObject.put("userRefId",uderidobj);

                JSONObject msgtempobi = new JSONObject();
                msgtempobi.put("messageTemplateId", MessageTemplateId);

                jsonObject.put("messageTemplateId",msgtempobi);

                jsonObject.put("phoneNumber",Contact.get(i).getContactNumber());
                jsonObject.put("contactName",Contact.get(i).getContactName());
                jsonObject.put("gLatitude",Constants.USER_LATITUDE);
                jsonObject.put("gLongititude",Constants.USER_LONGITUDE);
                jsonObject.put("country",Constants.USER_COUNTRY);

                JSONObject crebyobj = new JSONObject();
                crebyobj.put("userId", sharedPreferences.getString("userid", ""));
                Constants.USER_ID=sharedPreferences.getString("userid", "");

                jsonObject.put("createdBy",crebyobj);

                jArray.put(jsonObject);

            }
            catch (JSONException e) {
                e.printStackTrace();
            }
        }


        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jArray.toString());
            Log.d("Object", String.valueOf(jArray));
        } catch (Exception e) {
            e.printStackTrace();
        }


        asyncHttpClient.addHeader("accept", "application/json;charset=UTF-8");

        asyncHttpClient.addHeader("auth-token", sharedPreferences.getString("tokenid",""));

        asyncHttpClient.addHeader("user-id", sharedPreferences.getString("userid",""));

        asyncHttpClient.addHeader("role-id", sharedPreferences.getString("roleid",""));

        asyncHttpClient.addHeader("service", Constants.ADD_CONTACT_SERVICE);
        Log.e("servicename",Constants.ADD_CONTACT_SERVICE);


        asyncHttpClient.post(null, Constants.APP_ADD_EMERGENCY_CONTACT_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("ContactResponse", Response);

                Log.v("Status code", statusCode+"");

                if (statusCode==201){


                    try {
                        JSONArray jsonArray=new JSONArray(Response);
                        for (int k=0; k<jsonArray.length(); k++) {
                            JSONObject object = jsonArray.getJSONObject(k);

                            JSONObject id = object.getJSONObject("userRefId");
                            es.putString(Constants.USER_ID, id.getString("userId"));

                            JSONObject msg = object.getJSONObject("messageTemplateId");
                            es.putString(MessageTemplateId, msg.getString("messageTemplateId"));

                            es.putString(Contact.get(k).getContactNumber(), object.getString("phoneNumber"));
                            es.putString(Contact.get(k).getContactName(), object.getString("contactName"));
                            es.putString(Constants.USER_LATITUDE, object.getString("gLatitude"));
                            es.putString(Constants.USER_LONGITUDE, object.getString("gLongititude"));
                            es.putString(Constants.USER_COUNTRY, object.getString("country"));

                            JSONObject createdBy = object.getJSONObject("createdBy");
                            es.putString(Constants.USER_ID, createdBy.getString("userId"));
                            Log.e("statuscode", String.valueOf(statusCode));

                        }


                        Log.e("CONTACT_LATITUDE",Constants.USER_LATITUDE);
                        Log.e("CONTACTS_LONGITUDE",Constants.USER_LONGITUDE);
                        Log.e("CONTACTS_COUNTRY",Constants.USER_COUNTRY);


                    } catch (JSONException e) {
                        e.printStackTrace();

                    }
                    Intent intent=new Intent(ChooseContact.this,SetFalseAlarmNoActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {

                    Toast.makeText(ChooseContact.this, "Contact Not Submitted", Toast.LENGTH_SHORT).show();
                }



            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                Log.e("Error",error.toString());
                Log.e("Errorstatus", String.valueOf(statusCode));

            }

        });


    }


    @Override
    public void onBackPressed() {
        finish();
    }
}