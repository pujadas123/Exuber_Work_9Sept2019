package com.example.exuberandroid.sentinel_module.Activities;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.telephony.TelephonyManager;
import android.test.mock.MockPackageManager;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.example.exuberandroid.sentinel_module.Utils.Utilities;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

public class SignupActivity extends AppCompatActivity implements TextWatcher, View.OnClickListener {
    EditText input_name,input_email,input_phn;
    TextView signBTN,txtmsg;

    String Otp,verification, ErrorStatus;

    private EditText editTextConfirmOtp;
    private TextView buttonResend,buttonConfirm;
    TextView txtShowOtp;

    //Volley RequestQueue
    private RequestQueue requestQueue;

    AlertDialog alertDialog;

    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;

    String DeviceId="9999";
    String DevicePlatform="ANDROID";

    ProgressDialog pd;

    CheckBox checkbox;
    TextView txt_Terms;

    TelephonyManager tm;
    String countryCodeValue;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        ////////
        sharedPreferences=getApplicationContext().getSharedPreferences("PREF",0);
        es=sharedPreferences.edit();
        es.apply();

        if (sharedPreferences.getString("isLoggedIn", "").equals("ACTIVE")) {
            startActivity(new Intent(SignupActivity.this, MainActivity.class));

        }
        if (sharedPreferences.getString("isLoggedIn", "").equals("AUTHORISED")) {
            startActivity(new Intent(SignupActivity.this, MainActivity.class));

        }




        /////

        init();


    }

    public void init(){

        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);
        input_name=(EditText)findViewById(R.id.input_name);
        input_name.addTextChangedListener(this);

        input_email=(EditText)findViewById(R.id.input_email);
        input_email.addTextChangedListener(this);

        input_phn=(EditText)findViewById(R.id.input_phn);
        input_phn.addTextChangedListener(this);

        signBTN=(TextView)findViewById(R.id.signBTN);
        signBTN.setOnClickListener(this);

        txtmsg=(TextView)findViewById(R.id.txtmsg);
        txtmsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SignupActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        });

        //Initializing the RequestQueue
        requestQueue = Volley.newRequestQueue(this);

        checkbox=(CheckBox)findViewById(R.id.checkbox);
        txt_Terms=(TextView)findViewById(R.id.txt_Terms);
        txt_Terms.setText(Html.fromHtml("<u>Terms and Conditions</u>"));

        txt_Terms.setClickable(true);
        txt_Terms.setMovementMethod(LinkMovementMethod.getInstance());
        String text = "<a href='https://s3-ap-southeast-1.amazonaws.com/sentineldocs/tandc.pdf'> Terms and Conditions </a>";
        txt_Terms.setText(Html.fromHtml(text));


    }


    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {

        if (input_name.getText().toString().length() > 0) {
            input_name.setError(null);
        }
        if (input_email.getText().toString().length() > 0) {
            input_email.setError(null);
        }
        if (input_phn.getText().toString().length() > 0) {
            input_phn.setError(null);
        }
    }


    private boolean validate_opt(String name, String email, String molibeNo, String recievedOtp, String typedOtp){

        if (editTextConfirmOtp.getText().toString().length() == 0) {
            editTextConfirmOtp.setError("Please Enter OTP");
            return false;
        }
        if (editTextConfirmOtp.getText().toString().trim().length() < 4){
            editTextConfirmOtp.setError("Please Enter OTP Properly");
            return false;
        }

        if (!recievedOtp.equals(typedOtp))
        {
            editTextConfirmOtp.setError("OTP not matching");
            return false;
        }
        else {
            editTextConfirmOtp.setError(null);

            try {


                JSONObject jObject = new JSONObject();

                jObject.put("userName",name);

                jObject.put("phoneNumber",molibeNo);

                jObject.put("userEmail",email);

                jObject.put("deviceId",DeviceId);

                jObject.put("gLatitude","");

                jObject.put("gLongitude","");

                //Log.e("check",sharedPreferences.getString("userEmail",Constants.USER_EMAIL));

                jObject.put("otp",recievedOtp);
                jObject.put("devicePlatform",DevicePlatform);

                jObject.put("country","");

                tm = (TelephonyManager)this.getSystemService(Context.TELEPHONY_SERVICE);
                countryCodeValue = tm.getNetworkCountryIso().toUpperCase();

                jObject.put("locale", countryCodeValue);


                OTPApiCall(name,email,molibeNo,jObject);

            } catch (Exception e) {
                e.printStackTrace();
            }

            alertDialog.dismiss();

        }
        return true;
    }



    private void confirmOtp(final String name, final String email, final String molibeNo, final String recievedOtp) throws JSONException {
        //Creating a LayoutInflater object for the dialog box
        LayoutInflater li = LayoutInflater.from(this);
        //Creating a view to get the dialog box
        final View confirmDialog = li.inflate(R.layout.dialog_confirm, null);

        //Initizliaing confirm button fo dialog box and edittext of dialog box
        buttonResend=(TextView)confirmDialog.findViewById(R.id.buttonResend);
        buttonConfirm = (TextView) confirmDialog.findViewById(R.id.buttonConfirm);

        editTextConfirmOtp = (EditText) confirmDialog.findViewById(R.id.editTextOtp);
        editTextConfirmOtp.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    alertDialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                }
            }
        });

        /*txtShowOtp=(TextView)confirmDialog.findViewById(R.id.txtShowOtp);
        txtShowOtp.setText(recievedOtp);*/

        //Creating an alertdialog builder
        final AlertDialog.Builder alert = new AlertDialog.Builder(this);

        //Adding our dialog box to the view of alert dialog
        alert.setView(confirmDialog);

        //Creating an alert dialog
        alertDialog = alert.create();


        //Displaying the alert dialog
        alertDialog.show();

        buttonConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //alertDialog.dismiss();

                //Getting the user entered otp from edittext
                final String typedOtp = editTextConfirmOtp.getText().toString().trim();

                validate_opt(name,email,molibeNo,recievedOtp,typedOtp);
            }
        });


        buttonResend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                alertDialog.dismiss();

                String Name=input_name.getText().toString().trim();
                String Email=input_email.getText().toString().trim();
                String MolibeNo=input_phn.getText().toString().trim();


                if (validateTextFields()) {
                    editTextConfirmOtp.setText("");
                        try {

                            JSONObject jsonObject = new JSONObject();


                            jsonObject.put("phoneNo", input_phn.getText().toString().trim());
                            jsonObject.put("locale", countryCodeValue);


                            UserSignup(Name,Email,MolibeNo,jsonObject);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                }
            }
        });
    }




    // validating email id
    public boolean isEmailValid(String email) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }




    public void UserSignup(final String Name, final String Email, final String MolibeNo, JSONObject jsonObject) {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jsonObject.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }


        asyncHttpClient.post(null, Constants.APP_SIGNUP_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                pd=new ProgressDialog(SignupActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(true);
                pd.setIndeterminate(false);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.e("Response", Response);
                /*sharedPreferences = getApplicationContext().getSharedPreferences("PREF", Context.MODE_PRIVATE);
                SharedPreferences.Editor es = sharedPreferences.edit();*/

                if (statusCode==200) {


                    try {

                        JSONObject object = new JSONObject(Response);

                        es.putString(Otp,object.getString("otp"));
                        //Log.e("SignUpOTP",Otp);

                        es.putString(MolibeNo, object.getString("phoneNo"));

                        verification = object.getString("dataStatus");

                        Log.d("Status",verification);

                        System.out.println("Response" + verification);

                        es.putString("isLoggedIn", "ACTIVE");

                        es.commit();

                        confirmOtp(Name,Email,MolibeNo,object.getString("otp"));

                        pd.dismiss();

                    } catch (JSONException e) {
                        e.printStackTrace();

                    }
                }
                else {

                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

                Log.e("SignUpError", String.valueOf(error));
                Log.e("SignUpErrorStatus", String.valueOf(statusCode));

            }
        });

    }



    public void OTPApiCall(final String name, final String email, final String molibeNo, JSONObject jObject) {

        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity = new StringEntity(jObject.toString());
            Log.d("Reg User Object", String.valueOf(jObject));
        } catch (Exception e) {
            e.printStackTrace();
        }

        asyncHttpClient.post(null, Constants.REGISTER_USER_API, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                pd=new ProgressDialog(SignupActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(true);
                pd.setIndeterminate(false);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("OTP_Response", Response);
                /*sharedPreferences = getApplicationContext().getSharedPreferences("PREF", Context.MODE_PRIVATE);
                SharedPreferences.Editor es = sharedPreferences.edit();*/


                if(statusCode == 200)
                {
                    try {
                        JSONObject job =new JSONObject(Response);
                        JSONObject accessTokenObj=job.getJSONObject("accessId");
                        JSONObject roleId=job.getJSONObject("roleId");

                        es.putString("name",job.getString("userName"));
                        es.putString("email",job.getString("userEmail"));
                        es.putString("phno",job.getString("phoneNumber"));


                        es.putString(DeviceId, job.getString("deviceId"));
                        es.putString(DevicePlatform, job.getString("devicePlatform"));

                        //////


                        es.putString("userid",job.getString("userId"));
                        es.putString("userkey",job.getString("userKey"));
                        es.putString("tokenid",accessTokenObj.getString("accessTokenId"));
                        es.putString("roleid",roleId.getString("id"));

                        es.commit();

                        Log.e("r uid",sharedPreferences.getString("userid", ""));


                        pd.dismiss();

                        /////////

                    }
                    catch (JSONException e){
                        e.printStackTrace();
                    }

                    Log.d("EmailCheck",sharedPreferences.getString("userEmail",email));

                    Constants.USER_PHNO=sharedPreferences.getString("phoneNumber",molibeNo);
                    Log.d("PhoneNumber",Constants.USER_PHNO);


                    es.commit();

                    Toast.makeText(SignupActivity.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignupActivity.this, PermissionCheck.class));


                }
                else
                {
                    Toast.makeText(SignupActivity.this, "Server Error", Toast.LENGTH_SHORT).show();
                }



            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Error", String.valueOf(error));
                Log.e("ErrorStatus", String.valueOf(statusCode));

                String Response = new String(responseBody);
                Log.e("Failure","fail");

                if (statusCode==400){
                    try {
                        JSONObject object=new JSONObject(Response);
                        String msg =object.getString("field1");
                        pd.dismiss();
                        Toast.makeText(SignupActivity.this, msg, Toast.LENGTH_SHORT).show();

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(SignupActivity.this, "Server Error", Toast.LENGTH_SHORT).show();
                    }



                }
                else
                {
                    Toast.makeText(SignupActivity.this, "Server Error", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }




    public boolean validateTextFields()
    {
    String Name, Email, MobileNo;
    Name=input_name.getText().toString().trim();
    Email=input_email.getText().toString().trim();
    MobileNo=input_phn.getText().toString().trim();

        if (Name.length() == 0) {
            input_name.setError("Please Enter Your Name");
            return false;
        }
        if (Name.length() > 50) {
            input_name.setError("Please Write Between Then 50 Characters");
            return false;
        } else {
            input_name.setError(null);
        }
        if (!isEmailValid(Email)) {
            input_email.setError("Invalid Email");
            return false;
        }
        if (Email.length() == 0) {
            input_email.setError("Please Enter Your Email");
            return false;
        } else {
            input_email.setError(null);
        }
        if (MobileNo.length() == 0) {
            input_phn.setError("Please Enter Your Mobile No");
            return false;
        }
        if (MobileNo.length() > 12) {
            input_phn.setError("Please Enter a Valid Mobile No");
            return false;
        }
        if (MobileNo.length() < 7) {
            input_phn.setError("Please Enter a Valid Mobile No");
            return false;
        } else {
            input_phn.setError(null);
        }
        return true;
    }


    @Override
    public void onClick(View view) {
        String Name=input_name.getText().toString().trim();
        String Email=input_email.getText().toString().trim();
        String MolibeNo=input_phn.getText().toString().trim();


        switch (view.getId()) {
            case R.id.signBTN:

                if (validateTextFields()) {
                    if (Utilities.isOnline(this)) {
                        if (checkbox.isChecked()) {
                            try {

                                JSONObject jsonObject = new JSONObject();

                               // jsonObject.put("otp", Otp);
                                //Log.e("CheckOTP",Otp);



                                tm = (TelephonyManager)this.getSystemService(Context.TELEPHONY_SERVICE);
                                countryCodeValue = tm.getNetworkCountryIso().toUpperCase();




                                jsonObject.put("phoneNo", input_phn.getText().toString().trim());
                                jsonObject.put("locale", countryCodeValue);

                                Log.e("Country_Code",countryCodeValue);


                                UserSignup(Name, Email, MolibeNo, jsonObject);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        else {
                            Toast.makeText(this, "Please check on Terms and Conditions", Toast.LENGTH_SHORT).show();
                        }


                    }
                    else {
                        Utilities.showNoConnectionToast(this);
                    }

                }
                break;
        }

    }


    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}
