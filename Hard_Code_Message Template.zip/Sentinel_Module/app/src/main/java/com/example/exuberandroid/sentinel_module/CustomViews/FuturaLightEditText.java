package com.example.exuberandroid.sentinel_module.CustomViews;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.EditText;

/**
 * Created by machine on 24/2/16.
 */
public class FuturaLightEditText extends EditText {

    public FuturaLightEditText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    public FuturaLightEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public FuturaLightEditText(Context context) {
        super(context);
        init();
    }

    private void init() {
        if (!isInEditMode()) {
            Typeface tf = Typeface.createFromAsset(getContext().getAssets(), "futura_light.ttf");
            setTypeface(tf);
        }
    }


}
