package com.example.exuberandroid.sentinel_module.CustomViews;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

@SuppressLint("AppCompatCustomView")
public class FuturaMediumTextView extends TextView {


    public FuturaMediumTextView(Context context) {
        this(context, null);
    }

    public FuturaMediumTextView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FuturaMediumTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        setTypeface(Typeface.createFromAsset(context.getAssets(), "futura_medium.ttf"));
    }
}
