package com.example.exuberandroid.sentinel_module.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exuberandroid.sentinel_module.R;
import com.example.exuberandroid.sentinel_module.Utils.Constants;
import com.example.exuberandroid.sentinel_module.Utils.Utilities;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

public class ForgotCredentialsActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {
    private Toolbar mToolbar;
    private TextView toolbarTV;

    String Status;

    TextView txtEmail,submitBTN;
    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor es;

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        sharedPreferences = getSharedPreferences("PREF", 0);
        es=sharedPreferences.edit();

        init();
    }


    private void init() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("Forgot Credentials");

        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);

        txtEmail=(TextView)findViewById(R.id.txtEmail);
        txtEmail.addTextChangedListener(this);

        submitBTN=(TextView)findViewById(R.id.submitBTN);
        submitBTN.setOnClickListener(this);
    }

    // validating email id
    public boolean isEmailValid(String email) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {

        if (Utilities.isOnline(this)) {
            if (!(txtEmail.getText().toString().length() == 0)) {
                if (txtEmail.getText().toString().trim().contains("@")) {

                    if (!isEmailValid(txtEmail.getText().toString().trim())) {
                        txtEmail.setError("Please Enter Valid Email Id");
                    }
                    if (txtEmail.getText().toString().length() == 0) {
                        txtEmail.setError("Please Enter Email Id");
                    } else {
                        txtEmail.setError(null);
                        try {
                            ForgotPasswordByEmailIdApiCall();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                } else {

                    if (txtEmail.getText().toString().trim().length() > 12) {
                        txtEmail.setError("Please Enter a Valid Mobile No");
                    }
                    if (txtEmail.getText().toString().trim().length() < 7) {
                        txtEmail.setError("Please Enter a Valid Mobile No");
                    } else {
                        txtEmail.setError(null);
                        try {
                            ForgotPasswordByMobileNoApiCall();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
            else {
                txtEmail.setError("Please Enter a Valid Email Id Or Mobile No");
            }
        }
    }


////For Email Id

    public void ForgotPasswordByEmailIdApiCall() {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch(Exception e) {
        }


        asyncHttpClient.get(null, Constants.DOMAIN + "/Admin/ForgotPasswordByEmail/" + txtEmail.getText().toString() + "/" , null, "application/json", new AsyncHttpResponseHandler() {

            @Override
            public void onStart() {
                super.onStart();
                pd=new ProgressDialog(ForgotCredentialsActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(true);
                pd.setIndeterminate(false);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("Response", Response);

                try {
                    JSONObject jsonObject=new JSONObject(Response);
                    es.putString("userEmail",jsonObject.getString("userEmail"));
                    Status=jsonObject.getString("verification");
                    Log.e("Status", String.valueOf(statusCode));


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (statusCode==200){
                    if (Response.isEmpty()) {
                        Toast.makeText(ForgotCredentialsActivity.this, "No User Exists With This Email", Toast.LENGTH_SHORT).show();
                        /*Intent intent = new Intent(ForgotCredentialsActivity.this, LoginActivity.class);
                        startActivity(intent);*/
                        pd.dismiss();
                    }
                    else if (!Response.isEmpty() && Status.equals("AUTHORISED")){
                        Toast.makeText(ForgotCredentialsActivity.this, "Please Check Your Email For Password", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(ForgotCredentialsActivity.this, LoginActivity.class);
                        startActivity(intent);
                        pd.dismiss();
                    }
                    else {

                    }
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("ErrorMSG", String.valueOf(error));
                Log.e("ErrorStatusMessage", String.valueOf(statusCode));
                pd.dismiss();


            }
        });
    }





    ////For Mobile Number

    public void ForgotPasswordByMobileNoApiCall() {
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient();
        StringEntity entity = null;
        try {
            entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch(Exception e) {
        }


        asyncHttpClient.get(null, Constants.DOMAIN + "/Admin/ForgotPasswordByPhoneNumber/" + txtEmail.getText().toString() + "/" , null, "application/json", new AsyncHttpResponseHandler() {

            @Override
            public void onStart() {
                super.onStart();
                pd=new ProgressDialog(ForgotCredentialsActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(true);
                pd.setIndeterminate(false);
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final String Response = new String(responseBody);
                Log.v("Response", Response);
                try {
                    JSONObject jsonObject=new JSONObject(Response);
                    es.putString("userEmail",jsonObject.getString("userEmail"));
                    Status=jsonObject.getString("verification");
                    Log.e("Status", String.valueOf(statusCode));


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (statusCode==200){
                    if (Response.isEmpty()) {
                        Toast.makeText(ForgotCredentialsActivity.this, "No User Exists With This Mobile Number", Toast.LENGTH_SHORT).show();
                        /*Intent intent = new Intent(ForgotCredentialsActivity.this, LoginActivity.class);
                        startActivity(intent);*/
                        pd.dismiss();
                    }
                    else if (!Response.isEmpty() && Status.equals("AUTHORISED")){
                        Toast.makeText(ForgotCredentialsActivity.this, "Please Check Your Messagebox For Password", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(ForgotCredentialsActivity.this, LoginActivity.class);
                        startActivity(intent);
                        pd.dismiss();
                    }
                    else {

                    }
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("ErrorMSG", String.valueOf(error));
                Log.e("ErrorStatusMessage", String.valueOf(statusCode));
                pd.dismiss();

            }
        });
    }










    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {
        if (txtEmail.getText().toString().length() > 0) {
            txtEmail.setError(null);
        }
    }
}
