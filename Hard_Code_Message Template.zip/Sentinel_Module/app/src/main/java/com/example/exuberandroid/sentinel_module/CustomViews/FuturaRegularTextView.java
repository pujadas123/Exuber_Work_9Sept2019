package com.example.exuberandroid.sentinel_module.CustomViews;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

public class FuturaRegularTextView extends TextView {

    public FuturaRegularTextView(Context context) {
        super(context);

        applyCustomFont(context);
    }

    public FuturaRegularTextView(Context context, AttributeSet attrs) {
        super(context, attrs);

        applyCustomFont(context);
    }

    public FuturaRegularTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

        applyCustomFont(context);
    }

    private void applyCustomFont(Context context) {
        Typeface customFont = FontCache.getTypeface("futura_regular.ttf", context);
        setTypeface(customFont);
    }

}
