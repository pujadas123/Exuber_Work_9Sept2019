package com.example.exuberandroid.sentinel_module.Activities;

import android.content.Intent;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.exuberandroid.sentinel_module.Adapters.SlidingImage_Adapter;
import com.example.exuberandroid.sentinel_module.R;
import com.viewpagerindicator.CirclePageIndicator;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity {
    private static ViewPager mPager;
    private static int currentPage = 0;
    private static int NUM_PAGES = 0;

    private int[] myImageList = new int[]{R.drawable.ic_launcher, R.drawable.safety_network,
            R.drawable.public_transport,R.drawable.community,R.drawable.mother_daughter};

    private ArrayList<Integer> ImagesArray = new ArrayList<Integer>();

    TextView txtPrevious,txtProceed,txtMsg,txtMsg2,txtMsg3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        init();

    }


    private void init() {

        txtPrevious=(TextView)findViewById(R.id.txtPrevious);
        txtProceed=(TextView)findViewById(R.id.txtProceed);
        txtMsg=(TextView)findViewById(R.id.txtMsg);
        txtMsg2=(TextView)findViewById(R.id.txtMsg2);
        txtMsg3=(TextView)findViewById(R.id.txtMsg3);

        for(int i=0;i<myImageList.length;i++)
            ImagesArray.add(myImageList[i]);

        mPager = (ViewPager) findViewById(R.id.pager);


        mPager.setAdapter(new SlidingImage_Adapter(SplashActivity.this,ImagesArray));


        CirclePageIndicator indicator = (CirclePageIndicator)
                findViewById(R.id.indicator);

        indicator.setViewPager(mPager);
        txtMsg.setText("Welcome To Sentinel");

        final float density = getResources().getDisplayMetrics().density;

        indicator.setRadius(5 * density);



        NUM_PAGES =myImageList.length;



        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES) {
                    currentPage = 0;
                }
                //mPager.setCurrentItem(currentPage++, true);
            }
        };
        /*Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 2000, 4000);*/

        // Pager listener over indicator
        indicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {
                currentPage = position;

                if(position == 0) {
                    txtMsg.setVisibility(View.VISIBLE);
                    txtPrevious.setVisibility(View.GONE);
                    txtMsg2.setVisibility(View.GONE);
                    txtMsg3.setVisibility(View.GONE);

                }
                else {
                    txtPrevious.setVisibility(View.GONE);
                }


                if(position == 1) {
                    //txtMsg.setText("Emergency Messages");
                    txtMsg.setVisibility(View.GONE);
                    txtMsg3.setVisibility(View.VISIBLE);
                    txtMsg2.setVisibility(View.VISIBLE);
                    txtMsg3.setText("Sentinels");
                    txtMsg2.setText("Build your team of trusted friends, family and colleagues who care about your safety and wellbeing. Rely on them when feeling insecure and during emergency situations.");
                    txtPrevious.setVisibility(View.VISIBLE);
                }
                else {
                    //txtProceed.setVisibility(View.GONE);
                }


                if(position == 2) {
                    txtMsg.setVisibility(View.GONE);
                    txtMsg3.setVisibility(View.VISIBLE);
                    txtMsg2.setVisibility(View.VISIBLE);
                    txtMsg3.setText("Prevention over Cure");
                    txtMsg2.setText("Take your safety into your own hands and call upon your Sentinels for aid. Develop a sense of safety around you and move towards universal security.");
                    txtPrevious.setVisibility(View.VISIBLE);
                }
                else {
                    //txtProceed.setVisibility(View.GONE);
                }

                if(position == 3) {
                    txtMsg.setVisibility(View.GONE);
                    txtMsg3.setVisibility(View.VISIBLE);
                    txtMsg2.setVisibility(View.VISIBLE);
                    txtMsg3.setText("Community");
                    txtMsg2.setText("Harness the power of the community to enlist nearby Sentinels to your aid. Utilize the collective good of human nature to protect and preserve.");
                    txtPrevious.setVisibility(View.VISIBLE);

                }
                else {
                    //txtProceed.setVisibility(View.GONE);
                }

                if(position == 4) {
                    txtMsg.setVisibility(View.GONE);
                    txtMsg3.setVisibility(View.VISIBLE);
                    txtMsg2.setVisibility(View.VISIBLE);
                    txtMsg3.setText("Comprehensive");
                    txtMsg2.setText("Completely free to use and includes a multitude of features\n" +
                            "- Panic Alerts\t- Safeguard Shield\t- Location Tracking\n" +
                            "- Communal Help\t- Timed Check\t- Safety Updates\n");
                    txtPrevious.setVisibility(View.VISIBLE);

                }
                else {
                    //txtProceed.setVisibility(View.GONE);
                }




            }

            @Override
            public void onPageScrolled(int pos, float arg1, int arg2) {

            }

            @Override
            public void onPageScrollStateChanged(int pos) {

            }
        });


        txtPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPager.setCurrentItem(mPager.getCurrentItem()-1);
            }
        });


        txtProceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (currentPage == 4)
                {
                    Intent intent=new Intent(SplashActivity.this,ChooseContact.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    mPager.setCurrentItem(mPager.getCurrentItem()+1);
                }

            }
        });

    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
