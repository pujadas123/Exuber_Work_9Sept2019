package com.example.exuberandroid.sentinel_module.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.exuberandroid.sentinel_module.R;

public class PrivacyPolicyActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private TextView toolbarTV;

    TextView txt_here;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_policy);

        init();
    }

    private void init() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarTV = (TextView) findViewById(R.id.toolbarTV);
        toolbarTV.setText("Privacy Policy");
        this.overridePendingTransition(R.anim.left_to_right,
                R.anim.right_to_left);


        txt_here=(TextView)findViewById(R.id.txt_here);
        txt_here.setClickable(true);
        txt_here.setMovementMethod(LinkMovementMethod.getInstance());
        String text = "<a href='https://policies.google.com/privacy?hl=en'> HERE </a>";
        txt_here.setText(Html.fromHtml(text));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
